const express = require('express');
const app = express();
const MovieExpressRoute = express.Router();
let filmSchema = require('../Model/Movie.model');

MovieExpressRoute.route('/').get(async (req, res, next) => {
    try {
        const data = await filmSchema.find();
        res.json(data);
    } catch (error) {
        return next(error);
    }
});


MovieExpressRoute.route('/Movie/:id').get(async (req,res, next) => {
    try {
        const data = await filmSchema.findById(req.params.id);
        res.json(data);
    } catch (error) {
        return next(error);
    }
});

// Adding a student
MovieExpressRoute.route('/add-movie').post(async (req, res, next) => {
    try {
      const movie = new filmSchema(req.body);
      const result = await movie.save();
      res.json(result);
    } catch (error) {
      return next(error);
    }
  });
  MovieExpressRoute.route('/movie/:id').delete(async (req, res, next) => {
    try {
      const movie = await filmSchema.findByIdAndRemove(req.params.id);
      res.status(200).json({
        msg: `Movie with id ${req.params.id} has been deleted`,
        deletedMovie: movie
      });
    } catch (error) {
      return next(error);
    }
  });
  MovieExpressRoute.route('/update-movie/:id').put(async (req, res, next) => {
    try {
        const updatedMovie = await filmSchema.findByIdAndUpdate(req.params.id, {
            $set: req.body
        }, { new: true });
        res.json(updatedMovie);
    } catch (error) {
        return next(error);
    }
});

module.exports = MovieExpressRoute;
